#ifndef DATA_H
#define DATA_H


class Data
{
public:
    Data();
};

#endif // DATA_H
