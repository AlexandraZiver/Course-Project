#include "mainwindow.h"
#include "ui_mainwindow.h"


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    auth = new authentication();

    connect(auth, &authentication::firstWindow, this, &MainWindow::show);
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_Exit_clicked()
{
    this->close();
}


void MainWindow::on_Start_Game_clicked()
{
    reg = new registr();
    reg->show();
    this->close();

}


void MainWindow::on_About_clicked()
{
    _about = new about;
    _about->show();
    this->close();


}


void MainWindow::on_Records_clicked()
{
    rec = new record;
    rec->show();
    this->close();
}

