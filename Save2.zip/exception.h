#ifndef EXCEPTION_H
#define EXCEPTION_H



#include <QDialog>

namespace Ui {
class exception;
}

class exception : public QDialog
{
    Q_OBJECT

public:
    explicit exception(QWidget *parent = nullptr);
    ~exception();

private slots:

private:
    Ui::registration *ui;
};

/*#include <exception>

QT_BEGIN_NAMESPACE
namespace Ui { class std::exception; }
QT_END_NAMESPACE


class Exception : public std::exception
{
    Q_OBJECT

public:
    Exception(QWidget *parent = nullptr);
    ~Exception();
    void nameChecked();
    void passwordCheck();
    void passwordControl();
//private slots:
    //void on_lineEdit_3_cursorPositionChanged(int arg1, int arg2);

private:
    Ui::MainWindow *ui;
};
*/
#endif // EXCEPTION_H
