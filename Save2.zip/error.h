#ifndef ERROR_H
#define ERROR_H


class Error
{
public:
    Error();
};

#endif // ERROR_H
