#include "error.h"

Error::Error()
{

}
