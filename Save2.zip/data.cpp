#include "data.h"

Data::Data()
{

}
