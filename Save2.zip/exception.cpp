/*#include "exception.h"
#include "ui_exception.h"

#include <QString>
#include <QMessageBox>
#include <QApplication>

/*std::exception::exception(QWidget *parent)
    : exception(parent)
    , ui(new ui::Exception)
{
    ui->setupUi(this);
}

void std::exception::nameChecked()
{
    QString name;
    name = ui->lineEdit_passwordCheck->text();

    if (name.length() < 3)
        QMessageBox::critical(this, "Password", "Ошибка! Введите больше 3 символов");
}

void std::exception::passwordControl()
{
    QString password1;
     password1 = ui->lineEdit->text();

      if (password1.length() < 3)
       QMessageBox::information(this, "Password", "Ошибка! Введите больше 3 символов");

}

void std::exception::passwordCheck()
{
    QString password1;
    QString password2;
    password1 = ui->lineEdit->text();
    password2 = ui->lineEdit_password->text();

    if (password1 != password2)
        QMessageBox::information(this, "Password", "Ошибка! Пароли не совпадают!");

}




std::exception::~std::exception()
{
    delete ui;
}*/
