#include "playplace.h"

PlayPlace::PlayPlace()
{

}
