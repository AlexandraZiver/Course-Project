#ifndef BALL_H
#define BALL_H


class Ball
{
public:
    Ball();
};

#endif // BALL_H
