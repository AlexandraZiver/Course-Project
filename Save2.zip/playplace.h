#ifndef PLAYPLACE_H
#define PLAYPLACE_H


class PlayPlace
{
public:
    PlayPlace();
    void generation();
        void buttonBackToPause();
        void gameButtonPress();
        void gameButtonLease();
        void saveData();
        void animation();
        void recieveData();
};

#endif // PLAYPLACE_H
