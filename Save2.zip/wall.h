#ifndef WALL_H
#define WALL_H


class Wall
{
public:
    Wall();
};

#endif // WALL_H
